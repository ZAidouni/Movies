import styled from "styled-components";

export default function ListWrapper() {
  return <Wrapper></Wrapper>;
}

const Wrapper = styled.ul`
  padding: 0;
`;
