import styled from "styled-components";

export default function CharacterCard() {
  return <Wrapper></Wrapper>;
}

const Wrapper = styled.li`
  list-style-type: none;
  margin: 0;
  padding: 16px;
  border-radius: 4px;
  background-color: ${(p) => p.theme.background2};
`;
