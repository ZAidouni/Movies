import styled from "styled-components";

export default function ErrorMessage() {
  return <Wrapper>Erreur de chargement</Wrapper>;
}

const Wrapper = styled.p``;
