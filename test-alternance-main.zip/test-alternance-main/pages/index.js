export default function Home() {
  return (
    <>
      <h2>Accueil</h2>
      <p>
        La série suit les mésaventures de Rick Sanchez, un scientifique cynique
        et fantasque, et de son petit-fils, Morty Smith, perturbé et facilement
        influençable, qui partagent leur temps entre une vie domestique et des
        aventures interdimensionnelles.
      </p>
      <p>
        Sur ce magnifique site, découvrez avec-nous les personnages de la série.
      </p>
    </>
  );
}
